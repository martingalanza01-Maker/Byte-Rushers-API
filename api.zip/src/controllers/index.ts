export * from './ping.controller';
export * from './resident.controller';

