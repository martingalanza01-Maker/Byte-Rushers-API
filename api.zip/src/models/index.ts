// export models
export * from './resident.model';
