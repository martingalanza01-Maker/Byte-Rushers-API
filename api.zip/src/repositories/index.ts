// export repositories
export * from './resident.repository';
